## Clicker Heroes API

[![Build Status](https://travis-ci.org/kernelcurry/clicker-heroes-api.svg?branch=master)](https://travis-ci.org/kernelcurry/clicker-heroes-api)
[![Total Downloads](https://poser.pugx.org/kernelcurry/clicker-heroes-api/downloads.svg)](https://packagist.org/packages/kernelcurry/clicker-heroes-api)
[![License](https://poser.pugx.org/kernelcurry/clicker-heroes-api/license.svg)](https://packagist.org/packages/kernelcurry/clicker-heroes-api)